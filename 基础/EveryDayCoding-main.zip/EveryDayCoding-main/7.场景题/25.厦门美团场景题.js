// 2[m]2[t] ->mmtt
// 2[m2[t]] ->mttmtt
// 2[m]2[t] ->mmtt

const fn = (data = {});
