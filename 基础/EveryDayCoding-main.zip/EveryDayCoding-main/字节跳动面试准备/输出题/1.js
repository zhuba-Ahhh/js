console.log(typeof typeof typeof null);
